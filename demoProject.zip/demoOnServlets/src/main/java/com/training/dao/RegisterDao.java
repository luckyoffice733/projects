package com.training.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RegisterDao {
	
	public String insert(String fn,String ln,String gd) {
		String msg=null;
		Connection con=DBUtil.getMySQLConnection();
		String query="insert into register values(?,?,?)";
		try {
			PreparedStatement pstmt =con.prepareStatement(query);
			pstmt.setString(1,fn);
			pstmt.setString(2,ln);
			pstmt.setString(3,gd);
			
			int i =pstmt.executeUpdate();
			if(i>0) {
				msg="Record is inserted";
			}else {
				msg="Record is not inserted";
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return msg;
	}

}
