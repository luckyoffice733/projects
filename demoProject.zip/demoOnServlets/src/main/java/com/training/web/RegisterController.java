package com.training.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.training.dao.RegisterDao;

@WebServlet("/register")
public class RegisterController extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.setContentType("text/html");
		
		PrintWriter out =resp.getWriter();
		
		//getting the form details
		String fname =req.getParameter("fn");
		String lname = req.getParameter("ln");
		String gender = req.getParameter("rd");
		 String chck[] =req.getParameterValues("c1");
		 String tarea = req.getParameter("ta");
		 String city = req.getParameter("ct");
				 String state = req.getParameter("st");
		
		out.println("Form Details are :");
		out.println("FirstName is : "+fname +"<br>");
		out.println("LastName is : "+lname+"<br>");
		out.println("Gender  is : "+gender+"<br>");
		out.println("Hobbies are : <br>");
		for(String c :chck) {
			out.println(c+"<br>");
		}
		out.println("<br>");
		out.println("ABout you: <br>");
		out.println(tarea);
		out.println("<br>");
		out.println("City is : "+city);
		out.println("<br>");
		out.println("State is : "+state);
		out.println("<br>");
		
		out.println("<a href='Register.jsp'>Click Here to Register</a>");
		//Creating object for Dao class
		RegisterDao rdao = new RegisterDao();
		String rs = rdao.insert(fname, lname,gender);
		out.println("<br> Message : "+rs);
		
		out.close();	
	}
	
}
