package com.training.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/ws") //url-pattern
public class WelcomeServlet extends HttpServlet{
	
	//override a service method from HttpServlet
    @Override
    public void init() throws ServletException {
    	System.out.println("we are in init method");
    }

	protected void service(HttpServletRequest req,HttpServletResponse resp) throws IOException {
		resp.setContentType("text/html");
		int count=0;
		PrintWriter out=resp.getWriter();
		out.println("welcome to servlets Using Service Method <br>");
		out.println("<p style='color:blue'>HelloWorld</p>");
		System.out.println("we are in servlet Service method ");
		
		out.close();
		
	}

	@Override
	public void destroy() {
	System.out.println("we are in destory method");
	}
	
}







